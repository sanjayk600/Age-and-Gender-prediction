# age-and-gender-prediction-using-cnn
age and gender prediction using the CNN model </br>

download the dataset from this link "https://www.kaggle.com/datasets/nipunarora8/age-gender-and-ethnicity-face-data-csv"
